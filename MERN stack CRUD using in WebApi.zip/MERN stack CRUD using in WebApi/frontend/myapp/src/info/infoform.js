import React from 'react';
// eslint-disable-next-line 

class Infoform extends React.Component{
   constructor(){
       super();
       this.state = {
           _id : "",
           Name : "",
           Age : "",
           City : "",
           isEdit : false
          
       }
   }
   infoChange = event =>
   {
       const {name , value} = event.target;

       this.setState({
           [name] : value
       })
   }
   infoSubmit = (event) =>
   {
       if (!this.state.isEdit) {
            event.preventDefault();
            let data = {
                isEdit:this.state.isEdit,
                Name : this.state.Name,
                Age : this.state.Age,
                City : this.state.City
            }
            this.props.myData(data);
            
        }
        else
        {
            event.preventDefault();
            let data = {
                isEdit:this.state.isEdit,
                _id : this.state._id,
                Name : this.state.Name,
                Age : this.state.Age,
                City : this.state.City
            }
            this.props.myData(data);
        }
    
   }

   componentWillReceiveProps(props){
       console.log(props.setForm);
       if (props.setForm._id !=null) {
           this.setState({
                isEdit : true,
                _id : props.setForm._id,  
                Name : props.setForm.Name,
                Age : props.setForm.Age,
                City : props.setForm.City
           })
       }
   }
 
    render()
    {
        return (
            <form class="form mt-5" onSubmit = {this.infoSubmit} autoComplete = "off">
                
            <label htmlFor="Name">Name :</label><br/>
            <input type="text"
                onChange = {this.infoChange}
                name="Name" 
                value={this.state.Name}
            />
            <br/><br/>
            <label htmlFor="age">Age  :</label><br/>
            <input type="text" name="Age" id="age"
                onChange = {this.infoChange}
                value={this.state.Age}
                
            />
            <br/><br/>
            <label htmlFor="city">City  :</label><br/>
            <input type="text" name="City" id="city"
                onChange = {this.infoChange}
                value={this.state.City}
                
            />
            <br/><br/>
            <button type="submit" className ="btn btn-primary">{this.state.isEdit ? "Update" : "Create"} </button>
            </form>
        )
    }

}

export default Infoform;