import React from 'react';
import Infoform from './infoform.js'
import Infopara from "./infopara.js";
import axios from 'axios';

class App extends React.Component{

 constructor() {
    super();
    this.state = {
        data : [],
        editdata : []
    }
 }   

create = data =>
{
    if (!data.isEdit) {
        axios.post("http://localhost:8000/info",data)
        .then(res => {
        console.log(res)
        this.getAll();
    })
        .catch(err => {
        console.error(err); 
    })
    }
    else{
        axios.put("http://localhost:8000/info/update",data)
        .then(res => {
            console.log(res);
            this.getAll();
        })
        .catch(err => {
            console.error(err); 
        })
    }
    
}
componentDidMount(){
    this.getAll();
}
getAll(){
    axios.get("http://localhost:8000/info").then(res => {
       this.setState({
            data : res.data
        })
        console.log(res.data);
    })
    
}
update = data =>{
    console.log(data);
    this.setState({
        editdata : data
    })
}
delete = data =>
{
  var option = window.confirm(`Are Sure Want To Delete ${data.Name}`);
  if (option) {
      axios.delete(`http://localhost:8000/info/del/${data._id}`).then(res=>{
        console.log(res);
        this.getAll(); 
      })
  }
}

render(){
    return <div className="container mt-5"> 
        <div className="row ">
            <div className="col-6">
                <h1>Registration from</h1>
                <Infoform myData = {this.create} setForm = {this.state.editdata}/>
            </div>
            <div className="col-6">
                <h1 className="head ml-5">Company registrations</h1>
                <Infopara getData = {this.state.data} setData = {this.update} delData = {this.delete}/>
            </div>
        </div>
    </div>
   
  }
}
export default App;

