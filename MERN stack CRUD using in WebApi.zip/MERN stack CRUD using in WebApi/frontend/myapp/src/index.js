import React from 'react';
import ReactDOM from "react-dom";
import App from "./info/app.js";


ReactDOM.render(<App/>,document.getElementById("root"));